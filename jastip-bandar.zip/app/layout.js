export const metadata = {
  title: "Jastip Bandar",
  description: "Jasa Titip & Antar di Batang, Jawa Tengah",
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
